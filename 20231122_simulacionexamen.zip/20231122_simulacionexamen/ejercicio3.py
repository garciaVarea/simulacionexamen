"""Actividad 3
En consola pides número inicial.
En consola pides número final.
Muestra una lista con todos los números pares que hay entre
estos dos números.

algoritmo funciona:5 puntos
algoritmo utiliza mejora en argumentos : 5 puntos
algoritmo controla errores y excepciones : 5 puntos
algoritmo aplica funciones anónimas o recursividad : 5 puntos
algoritmo resuelve una mejora de funcionalidad : 5 puntos"""
def obtener_numeros_pares(inicial, final):
    if not inicial.isdigit() or not final.isdigit():
        print("Error: Ingrese números enteros para el número inicial y final.")
        return None
    inicial = int(inicial)
    final = int(final)
    if inicial > final:
        print("Error: El número inicial debe ser menor o igual al número final.")
        return None
    numeros_pares = [num for num in range(inicial, final + 1) if num % 2 == 0]
    return numeros_pares

def actividad3():
    num_inicial = input('Ingrese el número inicial: ')
    num_final = input('Ingrese el número final: ')
    lista_pares = obtener_numeros_pares(num_inicial, num_final)
    if lista_pares is not None:
        print(f'Números pares entre {num_inicial} y {num_final}: {lista_pares}')

actividad3()