"""Actividad 2
En consola se piden las unidades y el precio.
Estos datos permiten calcular el subtotal.
Si el día de hoy es anterior al 15 de cada mes, se aplica
un descuento del 5%
Muestra el resultado el total de la factura.

algoritmo funciona:5 puntos
algoritmo utiliza mejora en argumentos : 5 puntos
algoritmo controla errores y excepciones : 5 puntos
algoritmo aplica funciones anónimas o recursividad : 5 puntos
algoritmo resuelve una mejora de funcionalidad : 5 puntos"""
import datetime
def calcular_total(unidades, precio):
    try:
        subtotal = unidades * precio
        hoy = datetime.datetime.now().day
        descuento = 0.05 if hoy < 15 else 0
        total = subtotal - (subtotal * descuento)
        return total
    except Exception as e:
        print(f'Error inesperado: {e}')
        return None
def actividad2():
    try:
        unidades = int(input('Ingrese la cantidad de unidades: '))
        precio = float(input('Ingrese el precio por unidad: '))
        total_factura = calcular_total(unidades, precio)
        if total_factura is not None:
            print(f'Total de la factura: {total_factura}')
    except ValueError:
        print('Error: Ingrese un número válido para unidades y precio.')

actividad2()