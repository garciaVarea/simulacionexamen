from enum import Enum

class Color(Enum):
    AZUL = 'azul'
    ROJO = 'rojo'
    VERDE = 'verde'
    # Agrega más colores si es necesario

class Mesa:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio

class Silla:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio

class Lampara:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio

if __name__ == "__main__":
    try:
        silla_azul = Silla(Color.AZUL, 9.95)
        silla_roja = Silla(Color.ROJO, 9.95)
        print(f"Silla azul - Color: {silla_azul.color.value}, Precio: {silla_azul.precio}")
        print(f"Silla roja - Color: {silla_roja.color.value}, Precio: {silla_roja.precio}")
    except Exception as e:
        print(f'Error inesperado: {e}')