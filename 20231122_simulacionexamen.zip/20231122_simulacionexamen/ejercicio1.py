def sumar_numeros():
    numeros = []
    try:
        while len(numeros) < 5:
            num = input('Ingrese un número o presione "q" para terminar: ')
            if num.lower() == 'q':
                break
            if num.isdigit():
                numeros.append(int(num))
            else:
                print('Error: Por favor, ingrese un número entero válido.')
        suma = sum(numeros)
        print(f'La suma de los números es: {suma}')
    except Exception as e:
        print(f'Error inesperado: {e}')

sumar_numeros()
